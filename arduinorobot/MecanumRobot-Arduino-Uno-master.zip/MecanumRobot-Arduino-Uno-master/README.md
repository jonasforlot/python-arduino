1. # mecanum-robot-kit-for-Arduino uno -PCA9685-HR8833
2. mecanum robot kit 
3. Power supply: 6-11.1v; For example, if you use 12V motor, you can use 11.1V 3s lipo battery.
4. Servos power supply: 5-8.4v, and select the power supply according to the model of the servos; if you don't use servos, you needn't connect to servo power.
5. Reserve 11pcs robot arm servos interface, compatible with WIFI/Bluetooth/PS2 controller.
6. This 4 channel motor drive board also can be used in 2/3WD robot car.

7. When you download the PS2 code or bluetooth code, if you don't have library file, you need to install and download it.
// NOTE: Requires FaBoPWM_PCA9685 installed.
// 1) open Sketch -> Include Library -> Add .ZIP Library
// 2) select "PS2X_lib"
 NOTE: Requires the PS2X_lib installed.
// 1) open Sketch -> Include Library -> Add .ZIP Library
// 2) select "FaBoPWM_PCA9685"
