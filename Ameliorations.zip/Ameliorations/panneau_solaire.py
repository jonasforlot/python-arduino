from time import sleep   # pour faire des "pauses" dans l'exécution du programme
from nanpy import SerialManager
from nanpy import ArduinoApi
from Arduinoconnect import connect # pour la reconnaissance de la carte Arduino (avec détection de port et vérification du téléversement de nanpy)

from Arduinoconnect import detectePortArduino # pour la reconnaissance de la carte Arduino (avec détection de port et vérification du téléversement de nanpy)
from nanpy import Servo  # pour utiliser le servomoteur
#########################################  COMMUNICATION AVEC CARTE ARDUINO ET DEFINITION DES BROCHES ET VARIABLES  #######################################################

port = detectePortArduino()
connection = SerialManager(device=port) #indiquer le bon port de la carte Arduino

a = ArduinoApi(connection=connection) #connection à la carte Arduino, on précédera chaque instruction Arduino par a. (exemple a.pinMode(2,a.OUTPUT)



servo1 = Servo(9,connection=connection) # on attribue la broche 9 pour l'instruction donné au servomoteur

servo2 = Servo(10, connection=connection) # on attribue la broche 9 pour l'instruction donné au servomoteur


angleNS=90
angleEO=90

while (True):
  valEO=a.analogRead(0)
  valNS=a.analogRead(1)
  print("Capteurs E0 : {}  -- NS : {} Servos EO : {}  -- NS : {}".format(valEO,valNS,angleEO,angleNS))



  if angleNS<150 and angleEO <150 and  angleEO > 60 and  angleNS > 60 :
    if (valNS<512):
      angleNS-=1
    else:
      angleNS+=1

    if (valEO>512):
      angleEO-=1
    else:
      angleEO+=1

    servo1.write(angleEO)
    servo2.write(angleNS)

  else :
    angleNS = 90
    angleEO = 90
    servo1.write(angleEO)
    servo2.write(angleNS)
    sleep(0.1)


  sleep(0.1)

