import serial
import serial.tools.list_ports
import pylab as pl
from matplotlib import animation





# Récupération port Arduino
def recup_port_arduino() :
    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        if 'Arduino' in p.description :
            mData = serial.Serial(p.device,9600)
    print(mData.is_open) #Print and check if the port is open
    print(mData.name) # Print the name of the port
    return mData

Data =recup_port_arduino()
#initialisation des listes
lX=[]
lY=[]
for k in range(10) :
    line1 = Data.readline()
    print (line1)
    donnee=line1.strip().split()[2].decode()
    print (donnee)
    lX.append(k)
    lY.append(float(donnee))
Data.close()
# # Création figure
# fig=pl.figure()
# line, = pl.plot([],[])
# pl.xlim(0, 20)
# pl.ylim(0,10)
# pl.grid()
#
# #Animation
# ani = animation.FuncAnimation(fig, animate, init_func=init, frames=21, blit=True, interval=500,repeat=False)
# pl.show()


