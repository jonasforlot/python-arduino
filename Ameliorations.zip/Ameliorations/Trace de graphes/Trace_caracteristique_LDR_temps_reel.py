
"""
Programme Python pour récpérer les donnnées d'n code Arduino permettant de tracer une caractéristique d'une photorésistance (ou autre capteur résistif).
Montage : Une tension de 5 V est appliquée aux deux points extrêmes d'un potentiomètre. On crée une alimentation variable en récupérant la tension entre le point milieu et la masse .
On applique cette tension à une association série photorésistance avec résistance connue (220, ohms)-. On fait mesurer par Arduino la tension aux bornes de la photorésistance et l'intensité parcourant le circuit I = (tension alim - tension photorésistance)/R.
"""

#########################################  IMPORTATION DES BIBLIOTHEQUES ET MODULES  ########################################################

import numpy   # numpy pour les maths , par exemple pour créer 256 valeurs régulièrement espacées entre 0 et 10 : np.linspace(0,10,256)
from time import sleep             # pour faire des "pauses" dans l'exécution du programme
import matplotlib.pyplot as plt # pour les graphiques
import matplotlib.animation as animation

from threading import Thread
from scipy import stats # module permettant de faire la régression linéaire à partir d'une liste X et d'une liste Y, stats.linregress(X,Y) renvoie 5 valeurs. Les 3 premières valeurs sont la pente, l'ordonnée à l'origine, et le coefficient de corrélation (à mettre au carré)


import serial
import serial.tools.list_ports

import time
import sys

#########################################  COMMUNICATION AVEC CARTE ARDUINO ET DEFINITION DES VARIABLES  #######################################################

R= 1000.0 # valeur de résistance connue pour mesure de l'intensité

U=[]
I=[]
temps=[]
U_alim = 0.0
courant_A =0.0
lines = ['I(mA)\tU(V)\n']
#





class dynamic_Graph_thread(Thread):

    def __init__(self):
        Thread.__init__(self)

    def run(self):

        # fig = plt.figure() # initialise la figure


        fig=plt.figure()
        line0, = plt.plot([],[])
        plt.xlim(0, 5)
        plt.ylim(0,5)
        plt.xlabel("I")
        plt.ylabel("U")




        # fonction à définir quand blit=True
        # crée l'arrière de l'animation qui sera présent sur chaque image
        def init():
            line0.set_data([],[])


            return line0,



        def animate(i):

            line0.set_data(I, U)



        ani = animation.FuncAnimation(fig,animate,10000,interval=20,repeat=False)

        plt.show()

        plt.close()

        eq = stats.linregress (I,U) # pour faire la régression linéaire

        pente = eq[0] # pente
        ordorig = eq[1] # ordonnée à l'origine
        coeff2 = eq[2]**2 # coefficient de corrélation au carré r²

        Xcalc = numpy.linspace(0,max(I) , 256) # création de points pour le tracé du modèle : on crée 256 points régulièrement espacés entre 0 et la valeur max de I
        Ycalc = pente*Xcalc+ordorig # on fait calculer U avec les paramètres de la régression linéaire pour ces valeurs de I

        global texte
        texte = 'equation de la droite  U = '+str(round(pente,3))+' I + '+str(round(ordorig,3))+'     R² = '+str(round(coeff2,3)) # on affiche l'équation de la droite avec 3 décimales

        print (texte)



        for i in range (len (I)):
            line = str(I [i]) +'\t'+ str(U[i])+'\n'
            lines.append(line)



        open('p:\Mes documents\essais Python\Améliorations\Tracé de graphes\data.txt', 'w').writelines(lines) #création d'un nouveau fichier texte sans la première ligne
        # data = numpy.loadtxt('data.txt')# importation du nouveau fichier texte pour récupérer les valeurs det, x et y dans un tableau

        plt.title('U=f(I)') # titre du graphique
        plt.scatter(I,U, color ='r', marker = 'o') # On affiche les points de coordonnées (I,U) avec des points rouges
        plt.plot(Xcalc,Ycalc,color = 'b',label = texte) # Affichage de la courbe modélisée en bleu

        plt.xlim (min(I),max(I))  #limtes pour les axes avec les valeurs extrêmes de I et de U
        plt.ylim(min(U),max(U))
        plt.legend()   # pour afficher les légendes (label)
        plt.show()



class Update_thread(Thread):

    def __init__(self):
        Thread.__init__(self)

    def run(self):

        ne=10
        t_acquisition =15
        t_reel =0
        t_reel_fin=t_acquisition
        t_clock = time.time()
        # reconnaissance automatique du port utilisé par Arduino
        ports = list(serial.tools.list_ports.comports())
        for p in ports:
            print (p)
            if 'Arduino' in p.description :
                mData = serial.Serial(p.device,9600,timeout =1)
            else :
                print ("Pas de carte Arduino détectée")
                sys.exit()

        print(mData.is_open) # indique si le port est ouvert
        print(mData.name) # indique le nom du port


        #########################################  ACQUISITION  AVEC ARDUINO EN LANGAGE PYTHON     ##############################################################################

        while t_reel < t_acquisition: # on agit sur le potentiomètre pour faire varier la tension U_alim de 0 à 5V, une mesure sera faite toutes les 2 secondes. Dès que la tension maximale est atteinte, le programme s'arrête
            line = mData.readline()  # Lit la ligne venant du port série.
            print (line)
            listeDonnees = line.strip()
            listeDonnees = line.split() # on sépare les données de la ligne  et on les stocke dans une liste
            print(listeDonnees)  # affichage de la liste obtenue.
            if len(listeDonnees)!=0: # extraction des données (valeurs d'intenisté et tension)

                try :
                    tension = float(listeDonnees[2].decode())
                    courant = float(listeDonnees[5].decode())
                except ValueError :
                    print ("Fin des mesures")
                    mData.close()
                    break
                U.append(tension)
                print("U = %f"%(tension))

                I.append(courant)
                print("I = %f"%(courant))
                t_clock_new = time.time()
                temps.append(t_reel)
                print("temps = %f"%(t_reel))
                t_reel = t_reel + t_clock_new-t_clock # instant réel
                t_clock = t_clock_new



            else :

                pass
            # time.sleep (2)

        mData.close()


        #################################   REGRESSION LINEAIRE ET TRACE DE GRAPHIQUE ########################################################################################
        # global eq
        # eq = stats.linregress (I,U) # pour faire la régression linéaire
        #
        # pente = eq[0] # pente
        # ordorig = eq[1] # ordonnée à l'origine
        # coeff2 = eq[2]**2 # coefficient de corrélation au carré r²
        #
        # Xcalc = numpy.linspace(0,max(I) , 256) # création de points pour le tracé du modèle : on crée 256 points régulièrement espacés entre 0 et la valeur max de I
        # Ycalc = pente*Xcalc+ordorig # on fait calculer U avec les paramètres de la régression linéaire pour ces valeurs de I
        #
        # global texte
        # texte = 'equation de la droite  U = '+str(round(pente,3))+' I + '+str(round(ordorig,3))+'     R² = '+str(round(coeff2,3)) # on affiche l'équation de la droite avec 3 décimales
        #
        # print (texte)
        #
        #
        # mData.close()
        #
        # for i in range (len (I)):
        #     line = str(I [i]) +'\t'+ str(U[i])+'\n'
        #     lines.append(line)
        #
        #
        #
        # open('p:\Mes documents\essais Python\data.txt', 'w').writelines(lines) #création d'un nouveau fichier texte sans la première ligne
        # # data = numpy.loadtxt('data.txt')# importation du nouveau fichier texte pour récupérer les valeurs det, x et y dans un tableau


class Main_thread(Thread):

    def __init__(self):
        Thread.__init__(self)

    def run(self):

        UpdateThread = Update_thread()         # Create the thread Update.
        UpdateThread.start()                   # Start the thread Update.
        dynamicGraphthread =dynamic_Graph_thread()
        dynamicGraphthread.start()







if __name__ == "__main__":

    import sys
    MainThread = Main_thread()
    MainThread.start()
    MainThread.join()



#
# plt.title('U=f(I)') # titre du graphique
# plt.scatter(I,U, color ='r', marker = 'o') # On affiche les points de coordonnées (I,U) avec des points rouges
# plt.plot(Xcalc,Ycalc,color = 'b',label = texte) # Affichage de la courbe modélisée en bleu
# plt.xlabel('I')       # nommer l'axe des abscisses
# plt.ylabel('U')       # nommer l'axe des ordonnéees
# plt.xlim (min(I),max(I))  #limtes pour les axes avec les valeurs extrêmes de I et de U
# plt.ylim(min(U),max(U))
# plt.legend()   # pour afficher les légendes (label)
# plt.show()  #afficher le graphique (ne rien mettre dans la parenthèse)

