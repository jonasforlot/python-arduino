import serial
import serial.tools.list_ports
import pylab as pl
from matplotlib import animation



def init():
    line.set_data([],[])
    return line,

def animate(i):
    line1 = mData.readline()
    print (line1)
    liste_donnee = line1.strip().split()
    print (liste_donnee)
    donnee=line1.strip().split()[5].decode()
    print (donnee)
    lX.append(i)
    lY.append(float(donnee))

    line.set_data(lX,lY)
    return line,


# Récupération port Arduino
ports = list(serial.tools.list_ports.comports())
for p in ports:
    if 'Arduino' in p.description :
        mData = serial.Serial(p.device,9600)
print(mData.is_open) #Print and check if the port is open
print(mData.name) # Print the name of the port

#initialisation des listes
lX=[]
lY=[]

# Création figure
fig=pl.figure()
line, = pl.plot([],[])
pl.xlim(0, 20)
pl.ylim(0,200)
pl.grid()

#Animation
ani = animation.FuncAnimation(fig, animate, init_func=init, frames=2000, blit=True, interval=20,repeat=False)
pl.show()


mData.close()
