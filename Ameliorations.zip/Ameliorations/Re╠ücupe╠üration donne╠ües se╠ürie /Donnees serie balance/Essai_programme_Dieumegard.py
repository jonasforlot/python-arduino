import serial , time
import matplotlib.pyplot as plt
plt.ion() #passe en mode interactif, pour animation
ser = serial.Serial('Com22', 9600)
fichier=open("Enregistre.txt",'w',encoding = 'utf8')
t0=time.time()
try:
    while True:
        ligne = ser.readline().decode() #reçoit la valeur du port série
        ligne=time.asctime()+" "+ligne #ajoute ça au temps actuel
        print (len(ligne))
        if len(ligne)==47 :
            masse=ligne.split()[6]
            print (masse) # affiche temps + mesures
            fichier.write(str(masse)) # et l'écrit dans le fichier
            t=time.time()-t0

            plt.scatter(t,masse )
            plt.show()
            plt.pause(0.01) #nécessaire pour l'animation
            time.sleep(1) # nombre de secondes entre 2 mesures
except KeyboardInterrupt: # arrêt par Controle-C ?
    print("boucle interrompue")
    fichier.close()
ser.close()
plt.close()