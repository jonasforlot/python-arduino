from nanpy import ArduinoApi    # importation des bibliothèques pour communication avec Arduino
from nanpy import SerialManager
from nanpy import Servo  # pour utiliser le servomoteur
from time import sleep    # pour faire des "pauses" dans l'exécution du programme

#########################################  COMMUNICATION AVEC CARTE ARDUINO ET DEFINITION DES BROCHES ET VARIABLES  #######################################################
connection = SerialManager(device='COM8') #indiquer le bon port de la carte Arduino

a = ArduinoApi(connection=connection) #connection à la carte Arduino, on précédera chaque instruction Arduino par a. (exemple a.pinMode(2,a.OUTPUT)

servo1 = Servo(9, connection=connection) # on attribue la broche 9 pour l'instruction donné au servomoteur

servo2 = Servo(10, connection=connection) # on attribue la broche 9 pour l'instruction donné au servomoteur

# servo1=Servo(ar1,1) # pin 9   EO
# servo2=Servo(ar1,2) # pin 10  NS


servo1.write(180)
servo1.write(0)
servo2.write(180)
servo2.write(0)
servo2.write(90)

# capteurEO=a.analogRead(0)
# capteurNS=a.analogRead(0)

#

angleNS=90
angleEO=90
while (True):
  valEO=a.analogRead(0)
  valNS=a.analogRead(1)
  print("Capteurs E0 : {}  -- NS : {} Servos EO : {}  -- NS : {}".format(valEO,valNS,angleEO,angleNS))
  if (valNS<512):
    angleNS-=1
  else:
    angleNS+=1
  if (valEO>512):
    angleEO-=1
  else:
    angleEO+=1
  servo1.write(angleEO)
  servo2.write(angleNS)
  sleep(0.1)

