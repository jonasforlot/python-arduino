# -*- coding: utf-8 -*-

"""
Programme Python pour montage Arduino ouverture automatique de porte de poulailler
Partie capteur :
la photorésistance est privée de lumière (quand la nuit tombe) ou est éclairée.

Partie actionneur  :
Selon l’éclairement reçu par la photorésistance, le servomoteur prend une position à 45° ou 90°.
"""
#########################################  IMPORTATION DES BIBLIOTHEQUES ET MODULES  #############################################################################

from nanpy import ArduinoApi    # importation des bibliothèques pour communication avec Arduino
from nanpy import SerialManager
from time import sleep   # pour faire des "pauses" dans l'exécution du programme



from eurosmart import *             # Utilisation de la librairie Eurosmart
import sys


def main():

    # Configuration de la communication avec la carte EDUCA DUINO Lab
    portCom = detectePortComEducaDuinoLab()             # Disponible dans la librairie Eurosmart.
    if ('none' == portCom):
        print('Pas de carte EDUCA DUINO LAB connectée au PC')
        sys.exit();                                     # Sortie du programme.

    connection = SerialManager(device=portCom)          # Numéro de port utilisé par la carte.
    #connection = SerialManager(device='COM28')         # Windows: Le numéro de port est celui utilisé par la carte. Il est identifiable avec l'application "arduino"" par le menu [Outils][Port].

    try:
        a = ArduinoApi(connection=connection)
    except:
        print("La librairie nanpy n'a pas été téléversée dans la carte EDUCA DUINO LAB")
        sys.exit();                                     # Sortie du programme.


#########################################  COMMUNICATION AVEC CARTE ARDUINO ET DEFINITION DES BROCHES ET VARIABLES  #######################################################





    a.pinMode(2,a.OUTPUT) # Broche 2 déclarée comme sortie (pour allumer ou éteindre une LED associée en série avec une résistance de protection)

    #########################################   CODE ARDUINO  EN LANGAGE PYTHON    #################################################################################


    while True:
        Valeur_A0=a.analogRead(0) # lecture de la tension sur l'entrée analogique A0 (valeur comprise entre 0 et 1023 qui correspond à une tension entre 0 et 5V)
        Tension_A0=Valeur_A0*5.0/1023 # conversion de la valeur en V
        if (Tension_A0<1.0):             # Selon la tension lue, le LED s'allume ou s'éteint (ici on a choisi comme valeur de référence : 4V)
            a.digitalWrite(2,a.HIGH)


        else:
            a.digitalWrite(2,a.LOW)
        print (Tension_A0)
        sleep(0.25)
if __name__ == '__main__':
    main()