#-------------------------------------------------------------------------------
# Name:     Elab_Res_niv3
# Purpose:
#           Programme d'utilisation de la platine Eurosmart de mesure de résistances ELAB_Res.
#           La platine permet de mesurer les résistances de 820 ohms, 1000 ohms, 1200 ohms et celles de 2 LEDs.
#           La platine utilise 2 broches analogiques de la carte EDUCA DUINO Lab pour les mesures de tension et de courant.
#           La platine utilise 1 broche de sortie pour faire varier la tension aux bornes des résistances à mesurer.
#           Les mesures effectuées sont transmises au fil de l'eau sur la console python et sur un graphique en fin de cession.
#           L'utilisation du graphique nécessite d'installer la librairie "matplotlib"
#
# Author:   cletourneur
#
# Created:  31/01/2019
# Copyright:(c) eurosmart 2019
# Licence:  <your licence>
#-------------------------------------------------------------------------------

import matplotlib.pyplot as plt     # Utilisation de la libririe graphique

from nanpy import SerialManager     # Utiliser par l'interpreteur python pour communiquer
                                    # avec la carte EDUCA DUINO LAB
from nanpy import ArduinoApi        # Utilisation des services arduino.

from eurosmart import *             # Utilisation de la librairie Eurosmart.

from time  import sleep
import math

import sys



# Configuration de la communication avec la carte EDUCA DUINO Lab
portCom = detectePortComEducaDuinoLab()             # Disponible dans la librairie Eurosmart.
if ('none' == portCom):
    print('Pas de carte EDUCA DUINO LAB connectée au PC')
    sys.exit();                                     # Sortie du programme.

connection = SerialManager(device=portCom)          # Numéro de port utilisé par la carte.

# connection = SerialManager(device='COM12')         # Windows: Le numéro de port est celui utilisé par la carte. Il est identifiable avec l'application "arduino"" par le menu [Outils][Port].



try:
    a = ArduinoApi(connection=connection)
    print("La librairie nanpy a été téléversée dans la carte EDUCA DUINO LAB")
except:
    print("La librairie nanpy n'a pas été téléversée dans la carte EDUCA DUINO LAB")
    sys.exit();                                     # Sortie du programme.


#########################################  COMMUNICATION AVEC CARTE ARDUINO ET DEFINITION DES BROCHES ET VARIABLES  #######################################################





a.pinMode(2,a.OUTPUT) # Broche 2 déclarée comme sortie (pour allumer ou éteindre une LED associée en série avec une résistance de protection)

#########################################   CODE ARDUINO  EN LANGAGE PYTHON    #################################################################################


