

from nanpy import SerialManager     # Utiliser par l'interpreteur python pour communiquer
                                    # avec la carte EDUCA DUINO LAB
from nanpy import ArduinoApi        # Utilisation des services arduino.

from eurosmart import *             # Utilisation de la librairie Eurosmart.

from time  import sleep
import math

import sys

def main():

    # Configuration de la communication avec la carte EDUCA DUINO Lab
    portCom = detectePortComEducaDuinoLab()             # Disponible dans la librairie Eurosmart.
    if ('none' == portCom):
        print('Pas de carte EDUCA DUINO LAB connectée au PC')
        sys.exit();                                     # Sortie du programme.

    connection = SerialManager(device=portCom)          # Numéro de port utilisé par la carte.

    # try:
    #     connection = SerialManager(device='COM12')         # Windows: Le numéro de port est celui utilisé par la carte. Il est identifiable avec l'application "arduino"" par le menu [Outils][Port].
    # except:
    #     print("Erreur de port")
    #     sys.exit();

    try:
        a = ArduinoApi(connection=connection)
        print("La librairie nanpy a été téléversée dans la carte EDUCA DUINO LAB")
    except:
        print("La librairie nanpy n'a pas été téléversée dans la carte EDUCA DUINO LAB")
        sys.exit();                                     # Sortie du programme.


#########################################  COMMUNICATION AVEC CARTE ARDUINO ET DEFINITION DES BROCHES ET VARIABLES  #######################################################





    a.pinMode(2,a.OUTPUT) # Broche 2 déclarée comme sortie (pour allumer ou éteindre une LED associée en série avec une résistance de protection)

    #########################################   CODE ARDUINO  EN LANGAGE PYTHON    #################################################################################



if __name__ == '__main__':
    main()
