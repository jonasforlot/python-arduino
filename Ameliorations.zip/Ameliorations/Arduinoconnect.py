"""
Programme Python pour tester que nanpy a bien été téléversé dans Arduino
"""
#########################################  IMPORTATION DES BIBLIOTHEQUES ET MODULES  #############################################################################

from nanpy import ArduinoApi    # importation des bibliothèques pour communication avec Arduino
from nanpy import SerialManager
from nanpy import Servo
from time import sleep   # pour faire des "pauses" dans l'exécution du programme
import sys
import serial.tools.list_ports


# portCom = serial.tools.list_ports.comports()
# ports = list(serial.tools.list_ports.comports())
# for p in ports:
#     print ('port : ', p.device)
#     print ('vid : ', p.vid)
#     print ('pid : ', p.pid)


# # ###############  COMMUNICATION AVEC CARTE ARDUINO############################


def detectePortArduino():
    """
    Détecte le port série USB où est connectée la carte EDUCA DUINO LAB.
    """

    portCom = serial.tools.list_ports.comports()
    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        if ((p.vid==9025) and (p.pid==66)):
            print('Carte EDUCADUINO connectée')
            print ('port : ', p.device)
            print ('vid : ', p.vid)
            print ('pid : ', p.pid)
            return (p.device)


        pass

        if ((p.vid==9025 or p.vid==10755) and p.pid==67):
            print('Carte ARDUINO connectée')
            print ('port : ', p.device)
            print ('vid : ', p.vid)
            print ('pid : ', p.pid)
            return (p.device)

        pass





def connect():

    portCom = detectePortArduino()
    if (portCom == None  ):
        print('Pas de carte  connectée au PC')
        sys.exit();                                     # Sortie du programme.

    connection = SerialManager(device=portCom)          # Numéro de port utilisé par la carte.

    # connection = SerialManager(device='COM18') #indiquer le bon port de la carte Arduino
    try:
        arduino = ArduinoApi(connection=connection)
        print("La librairie nanpy est téléversée dans la carte ")
        return(arduino)

    except:
        print("La librairie nanpy n'a pas été téléversée dans la carte ")

def servoconnect(pin):

    portCom = detectePortArduino()
    if (portCom == None  ):
        print('Pas de carte  connectée au PC')
        sys.exit();                                     # Sortie du programme.

    connection = SerialManager(device=portCom)          # Numéro de port utilisé par la carte.

    # connection = SerialManager(device='COM18') #indiquer le bon port de la carte Arduino
    try:
        arduino = ArduinoApi(connection=connection)
        servo = Servo(pin,connection=connection)

        return(servo)

    except:
        print("La librairie nanpy n'a pas été téléversée dans la carte ")



if __name__ == '__main__':
    servoconnect(9)


